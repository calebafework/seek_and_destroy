#!/usr/bin/env ts-node
/*
 * Meridian lab checker (run by the vulnlab Worker against a session's cluster).
 *
 * Two jobs:
 *   1) invariants  - assert the lab deployed AND is correctly exploitable.
 *                    Used as the CI smoke gate and as a post-deploy sanity check
 *                    before a session is handed to a learner. Exit != 0 = broken.
 *   2) progress    - state-poll objectives that CANNOT be faked by the learner,
 *                    for scoring. Emits JSON the Worker stores in Mongo.
 *
 * Requires: kubectl on PATH, KUBECONFIG pointing at the session cluster.
 * Node 18+ (uses global fetch). No external deps.
 *
 * Usage:
 *   ts-node checker.ts invariants
 *   ts-node checker.ts progress --session <id>
 */
import { execFileSync } from "node:child_process";

const NS = process.env.LAB_NAMESPACE || "meridian";
const SA = `system:serviceaccount:${NS}:ledger-sa`;
const WEB = process.env.WEB_URL || "http://127.0.0.1:30080";
// The learner proves cluster-admin by creating this ConfigMap in kube-system.
// ledger-sa canNOT write ConfigMaps, so its presence requires true escalation
// (TokenRequest -> privileged SA, or pod-create -> node breakout).
const PROOF_NS = "kube-system";
const PROOF_CM = "meridian-pwned";
const ORIG_TARGET_BALANCE = 990000; // account 1003 seed balance

function kubectl(args: string[]): string {
  return execFileSync("kubectl", args, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });
}
function canI(verb: string, resource: string, extra: string[] = []): boolean {
  try {
    return kubectl(["auth", "can-i", verb, resource, `--as=${SA}`, ...extra]).trim() === "yes";
  } catch { return false; }
}
type Check = { name: string; ok: boolean; detail?: string };
const results: Check[] = [];
const add = (name: string, ok: boolean, detail?: string) => results.push({ name, ok, detail });

// ---- invariants: the lab must be *correctly vulnerable* --------------------
async function invariants(): Promise<boolean> {
  // K8s misconfigurations must be present and exploitable.
  add("rbac: ledger-sa reads secrets cluster-wide",
      canI("get", "secrets", ["--all-namespaces"]));
  add("rbac: ledger-sa can create pods (privesc surface)",
      canI("create", "pods", ["-n", NS]));
  add("rbac: ledger-sa can mint SA tokens (TokenRequest abuse)",
      canI("create", "serviceaccounts/token"));
  // The proof namespace must be write-gated for ledger-sa (else the cluster-admin
  // objective would be trivially satisfiable at the RCE stage).
  add("rbac: ledger-sa canNOT write ConfigMaps in kube-system (proof is gated)",
      canI("create", "configmaps", ["-n", PROOF_NS]) === false);

  // App tier must be reachable and the entry vuln must actually work.
  try {
    const h = await fetch(`${WEB}/api/health`).then(r => r.json());
    add("app: api reachable via web NodePort", h?.ok === true);
  } catch (e: any) { add("app: api reachable via web NodePort", false, e.message); }

  try {
    const r = await fetch(`${WEB}/api/login`, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ username: "admin'--", password: "x" }),
    }).then(r => r.json());
    add("app: SQLi auth bypass yields a token", typeof r?.token === "string");
  } catch (e: any) { add("app: SQLi auth bypass yields a token", false, e.message); }

  return report("INVARIANTS");
}

// ---- progress: unfakeable objective state ----------------------------------
async function progress(session: string): Promise<boolean> {
  const obj: Record<string, boolean> = {};

  // cluster-admin: proof ConfigMap exists AND carries this session id.
  try {
    const cm = JSON.parse(kubectl(["get", "configmap", PROOF_CM, "-n", PROOF_NS, "-o", "json"]));
    obj["cluster-admin"] = cm?.data?.session === session;
  } catch { obj["cluster-admin"] = false; }

  // bola: the high-value target account was drained (read straight from the DB,
  // so the learner can't spoof it through the app).
  try {
    const bal = kubectl(["exec", "-n", NS, "deploy/postgres", "--", "psql", "-U", "meridian",
      "-d", "meridian", "-tAc", "select balance from accounts where id=1003"]).trim();
    obj["bola"] = Number(bal) < ORIG_TARGET_BALANCE;
  } catch { obj["bola"] = false; }

  const payload = { session, objectives: obj, checkedAt: new Date().toISOString() };
  console.log(JSON.stringify(payload)); // Worker captures stdout -> Mongo
  return true;
}

function report(title: string): boolean {
  const pass = results.every(r => r.ok);
  console.error(`\n== ${title} ==`);
  for (const r of results) console.error(`${r.ok ? "PASS" : "FAIL"}  ${r.name}${r.detail ? "  (" + r.detail + ")" : ""}`);
  console.error(`\n${pass ? "ALL CHECKS PASSED" : "ONE OR MORE CHECKS FAILED"}\n`);
  return pass;
}

(async () => {
  const [mode] = process.argv.slice(2);
  const sessionIdx = process.argv.indexOf("--session");
  const session = sessionIdx > -1 ? process.argv[sessionIdx + 1] : "smoke";
  let ok = false;
  if (mode === "invariants") ok = await invariants();
  else if (mode === "progress") ok = await progress(session);
  else { console.error("usage: checker.ts <invariants|progress> [--session <id>]"); process.exit(2); }
  process.exit(ok ? 0 : 1);
})();
