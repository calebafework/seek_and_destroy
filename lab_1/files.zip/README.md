# Meridian Bank — vulnerable fintech lab

An intentionally vulnerable neobank for hands-on pentest training, packaged as a
self-contained bundle your vulnlab control plane can deploy into a disposable,
network-isolated **kind** cluster. One realistic app, many attack paths, a single
goal: **web → Kubernetes cluster-admin**.

> ⚠️ Intentionally insecure. Deploy only into a throwaway, offline kind cluster.
> Never expose it to a public network or reuse any code from it.

## What's in the box

```
meridian-lab/
├── lab.yaml                 # contract the Worker consumes (build/deploy/score/destroy)
├── README.md
├── docker-compose.yml       # local APP-tier smoke test (no K8s attack surface)
├── app/
│   ├── web/                 # neobank frontend; stored + reflected XSS
│   ├── api/                 # SQLi, BOLA/IDOR, JWT alg:none, SSRF, admin dump
│   └── ledger/              # internal-only; info disclosure + command injection
├── chart/                   # Helm chart = the full lab incl. K8s misconfig
│   ├── templates/
│   │   ├── 10-rbac.yaml         # over-permissioned ledger-sa (the privesc)
│   │   ├── 20-networkpolicy.yaml# default-deny isolation (can't phone home)
│   │   └── ...
│   └── files/seed.sql
├── attack/WALKTHROUGH.md    # instructor solution guide (the kill chain)
└── orchestrator/
    ├── INTEGRATION.md       # isolation model + Worker lifecycle + TS glue
    └── kind-config.yaml     # loopback-bound, per-session cluster config

## The intended chain (multiple paths at each step)

`SQLi / creds` → `BOLA drain accounts` → `JWT forge or XSS → admin` →
`SSRF into internal ledger` → `command injection RCE` →
`stolen SA token → cluster-admin`.

Full detail and alternates in `attack/WALKTHROUGH.md`.

## Vulnerability inventory

| Class | Location | Category |
|-------|----------|----------|
| SQL injection | `POST /api/login` | A03:2021 |
| Broken Object Level Authz | `/api/accounts/:id`, `/api/transfer` | API1:2023 |
| JWT `alg:none` + weak secret | api auth middleware | API2:2023 |
| Stored XSS | support ticket → agent inbox | A03:2021 |
| Reflected XSS | `GET /search?q=` | A03:2021 |
| SSRF | `POST /api/webhooks/test` | A10:2021 |
| Info disclosure | ledger `/internal/config` | A01:2021 |
| OS command injection | ledger `/internal/report` | A03:2021 |
| K8s RBAC over-permission | `ledger-sa` binding | K8s |
| Secrets in env / plaintext creds | pods + `users` table | K8s / A02 |

## Quick starts

**Full lab (with the Kubernetes track)** — how learners actually run it:
```bash
kind create cluster --name meridian --config orchestrator/kind-config.yaml
for s in web api ledger; do docker build -t meridian-lab/$s:latest app/$s; done
kind load docker-image meridian-lab/web:latest meridian-lab/api:latest meridian-lab/ledger:latest --name meridian
helm install meridian ./chart --namespace meridian --create-namespace
# open http://127.0.0.1:30080   (demo customer: casey / hunter2)

**App tier only (fast local smoke test, no K8s vulns):**
```bash
docker compose up --build   # http://localhost:8080

## How your control plane uses it
Your Worker reads `lab.yaml`, provisions an isolated kind cluster, runs the
`lifecycle.*` hooks, exposes only the web NodePort, polls `objectives[]` for
scoring, and tears the cluster down on expiry. See `orchestrator/INTEGRATION.md`
— it also covers the isolation guarantees that keep an owned lab from ever
touching your control plane.
