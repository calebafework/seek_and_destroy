# Integrating Meridian with your vulnlab control plane

This explains how your **Worker** (the deployer) turns this bundle into a running,
isolated lab, and — importantly — how the lab stays sealed off from your control
plane.

## Terminology (matching your architecture diagram)

| Your term | More precise term | Role |
|-----------|-------------------|------|
| "Orchestrator API" | **Control plane API** | REST surface, lab lifecycle, talks to Mongo/Rabbit/ES |
| Worker service | **Lab deployer / lifecycle agent** | Consumes Rabbit jobs, provisions + tears down labs |
| Docker/Kubernetes | **Orchestrator / scheduler** | The thing that actually schedules the lab's pods |
| "Isolated lab environment" | **Lab (target)** | This bundle |

So your instinct was right: the lab is the *target*, and it must be isolated
from the control plane. The word "orchestrator" is best reserved for Kubernetes.

## The isolation model (the part that matters)

The learner is *supposed* to reach cluster-admin inside the lab. That is only
safe if "inside the lab" is a throwaway world with no path back to your platform.
Three nested boundaries enforce that:

1. **One ephemeral kind cluster per session (primary boundary).**
   The Worker runs `kind create cluster --name lab-<sessionId>`. Each kind
   cluster is its own set of Docker containers on its own Docker network. Your
   control-plane services (Mongo, RabbitMQ, Elasticsearch, API) live on a
   *different* network and are never attached to it, so lab pods have no route
   to them. The Worker talks **outbound only** to the lab's API server.

2. **Default-deny NetworkPolicies + no internet egress (in-cluster boundary).**
   `chart/templates/20-networkpolicy.yaml` denies all egress by default and only
   re-opens the intra-cluster hops the attack chain needs (web→api, api→ledger,
   api→postgres, api/ledger→kube API). There is **no** allow rule for the
   internet or the host. A fully-owned lab still cannot exfiltrate or phone home.

3. **Teardown deletes the whole cluster (cleanup boundary).**
   `kind delete cluster` removes every container, network, and secret. Blast
   radius per session = one disposable cluster. Nothing persists.

### Worker checklist (enforce these regardless of the bundle)
- Do **not** run labs in the same cluster/namespace as the control plane.
- Do **not** attach control-plane services to the kind Docker network.
- Do **not** mount host paths or the host Docker socket into lab pods.
- Bind the exposed NodePort to `127.0.0.1` (or a per-user proxy), never `0.0.0.0`.
- Set a wall-clock TTL; auto-run `destroy` on expiry.
- Cap CPU/mem via kind config so a lab cannot starve the host.

## Lifecycle: how the Worker drives a session

```
Rabbit job: {action: "deploy", labId: "meridian-bank", sessionId: "abc123"}
      │
      ▼
1. kind create cluster --name lab-abc123        # isolated substrate
2. label default ns (kubernetes.io/metadata.name=default is set automatically)
3. build images from lab.yaml `images[]`  ->  kind load docker-image ...
4. run lab.yaml `lifecycle.deploy[]`            # helm install
5. run lab.yaml `lifecycle.ready[]`             # gate on rollouts
6. expose web NodePort via a per-session local proxy; write access URL to Mongo
      │
      ▼  (learner attacks; Worker polls flags for scoring)
      ▼
Rabbit job: {action: "destroy", sessionId: "abc123"}
      │
      ▼
7. run lab.yaml `lifecycle.destroy[]`           # kind delete cluster
```

The Worker only needs to read `lab.yaml`. It substitutes `{{cluster}}` with
`lab-<sessionId>` and `{{registry}}` with the local image prefix, then executes
the `lifecycle.*` command lists. No app-specific logic lives in the Worker.

## Scoring

`lab.yaml -> objectives[]` lists flags at each trust boundary. Two ways to grade:
- **Flag submission:** learner pastes a `MERIDIAN{...}` flag into your UI; the API
  checks it against the objective. Simple, no cluster access needed.
- **State polling:** the Worker runs a checker (e.g. `kubectl auth can-i --list`
  as `ledger-sa`, or a canary Secret read) to confirm an objective without
  trusting the learner. Recommended for the `cluster-admin` objective.

Store progress in Mongo keyed by `sessionId`; emit detection events to
Elasticsearch (your diagram already has the "logs, detection, search" box — the
NetworkPolicy denials and kube-audit logs make good detection content later).

## Minimal Worker glue (TypeScript sketch)

```ts
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { load } from "js-yaml";
import { readFileSync } from "node:fs";
const sh = promisify(execFile);
const run = (cmd: string) => sh("bash", ["-lc", cmd]);

export async function deployLab(bundleDir: string, sessionId: string) {
  const lab = load(readFileSync(`${bundleDir}/lab.yaml`, "utf8")) as any;
  const cluster = `lab-${sessionId}`;
  const registry = lab.metadata.id;

  await run(`kind create cluster --name ${cluster} --config ${bundleDir}/orchestrator/kind-config.yaml`);
  for (const img of lab.images)
    await run(`docker build -t ${registry}/${img.name}:latest ${bundleDir}/${img.context}`);
  const sub = (c: string) => c.replaceAll("{{cluster}}", cluster).replaceAll("{{registry}}", registry);
  for (const step of [...lab.lifecycle.deploy, ...lab.lifecycle.ready]) await run(sub(step));
}

export async function destroyLab(sessionId: string) {
  await run(`kind delete cluster --name lab-${sessionId}`);
}
```

See `orchestrator/kind-config.yaml` for a resource-capped, loopback-bound cluster.
