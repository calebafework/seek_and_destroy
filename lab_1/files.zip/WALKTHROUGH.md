# Meridian Bank — instructor solution guide

Spoilers. This is the reference solution for operators/graders. The lab is a
self-contained, disposable target; everything below happens inside the learner's
own ephemeral cluster. Base URL below is the exposed web NodePort
(`http://127.0.0.1:30080`), proxied to the API at `/api`.

There are **multiple independent ways** through each trust boundary — that's by
design, so different skill sets converge on the same cluster-admin goal.

---

## Boundary 1 — Unauthenticated → customer session

**Path A: SQL injection (`POST /api/login`).** The username/password are string-
interpolated into the query. Authentication bypass:

```
username: admin'--
password: anything
```

The `--` comments out the password check and returns the first matching row.
Because verbose SQL errors are returned, the schema is easy to enumerate for a
UNION-based dump too.

**Path B: legitimate creds.** `casey / hunter2` is printed on the login page for
onboarding realism.

➜ Objective `foothold`.

## Boundary 2 — Customer → other customers (BOLA/IDOR)

The token authorizes "you have a token", never "this object is yours".

- `GET /api/accounts/1003` → reads Priya's $990k account.
- `GET /api/accounts/1003/transactions` → her full ledger.
- `POST /api/transfer {"from":1003,"to":1001,"amount":990000}` → drain it.

➜ Objective `bola`, flag `MERIDIAN{b0la_priya_990k}`.

## Boundary 3 — Customer → admin

**Path A: forge the JWT (alg:none).** The verifier accepts the `none` algorithm.
Take your customer token, swap the header to `{"alg":"none","typ":"JWT"}`, set
`"role":"admin"` in the payload, drop the signature. `GET /api/admin/users` now
returns every row — including the plaintext admin password (credential reuse).

**Path B: forge with the weak secret.** The default HS256 secret
(`meridian-dev-secret-change-me`) is guessable/brute-forceable and is *also*
leaked in Boundary 5, so a properly signed `role:admin` token is trivial.

**Path C: stored XSS → agent takeover.** Submit a support ticket whose body is
HTML/JS. When `sam.support` (or admin) opens the agent inbox, the payload runs in
their authenticated origin and can exfiltrate their token to a listener *inside
the lab* (remember: no internet egress — use an in-cluster collector).

➜ Objective `admin`, flag `MERIDIAN{alg_none_or_xss_to_admin}`.

## Boundary 4 — Admin → internal network (SSRF)

The admin-only webhook tester fetches an arbitrary server-side URL and returns
the body. The `ledger` service is ClusterIP-only (no ingress), so this is the way
in:

```
POST /api/webhooks/test
{"url":"http://ledger:9000/internal/config"}
```

Returns the ledger's full environment. You can also point it at the Kubernetes
API (`https://kubernetes.default.svc`) to confirm cluster reachability.

➜ Objective `ssrf`, flag `MERIDIAN{ssrf_into_the_ledger}`.

## Boundary 5 — SSRF → RCE in the ledger pod

`ledger /internal/config` disclosed the env (JWT secret + PG creds — retro-
actively unlocking Boundary 3 Path B). Now chain SSRF into the command-injection
sink:

```
POST /api/webhooks/test
{"url":"http://ledger:9000/internal/report","method":"POST",
 "body":{"name":"x\"; id; cat /var/run/secrets/kubernetes.io/serviceaccount/token #"}}
```

The `name` is concatenated into a shell command, giving execution in the ledger
pod and reading its mounted ServiceAccount token.

➜ Objective `rce`, flag `MERIDIAN{ledger_cmd_injection}`.

## Boundary 6 — Ledger pod → Kubernetes cluster-admin

The ledger pod runs as `ledger-sa`, whose ClusterRoleBinding grants cluster-wide
`secrets: get/list` and `pods: create/exec` (see `chart/templates/10-rbac.yaml`).
Using the stolen token against `https://kubernetes.default.svc`:

1. **Harvest secrets everywhere:** `get secrets --all-namespaces` dumps every
   namespace's credentials (the intended "read all the things" win).
2. **Escalate to full control:** with `pods: create` you can schedule a pod that
   mounts a more privileged ServiceAccount (or a node-privileged pod) and pivot
   to node/cluster-admin. `serviceaccounts/token` lets you mint tokens for other
   SAs directly.

Either route satisfies the goal of total cluster ownership.

➜ Objective `cluster-admin`, flag `MERIDIAN{sa_token_to_cluster_admin}`.

---

## Alternate / secondary surfaces
- **Reflected XSS:** `GET /search?q=<script>...` for a phishing/demo lure.
- **Pinned vulnerable dependency:** the `api` service pins an old `node-fetch`
  (`2.6.6`), a documented-CVE version, as a "modern CVE" research surface. Left as
  an exercise; the primary chain does not require it.
- **Plaintext credential reuse:** the `users` dump gives passwords directly,
  enabling reuse against the staff accounts.

## Reset & cleanup
`lifecycle.reset` re-seeds the database (drop the postgres pod) for a fresh run.
`lifecycle.destroy` deletes the kind cluster, erasing all state.
