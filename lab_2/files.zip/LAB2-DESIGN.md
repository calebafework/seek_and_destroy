# Lab 2 — "Bazaar" (breadth template)

**Design sketch.** Where lab 1 (Meridian Bank) is one deep, mostly linear chain,
lab 2 is the opposite shape: a multi-tenant **marketplace** with **three fully
independent footholds**, each from a different skill domain, each *by itself*
sufficient to reach the same goal. No single "the" solution — the lab can't be
pattern-matched, and three different learners can succeed three different ways.

- Lab 1 `meridian-bank` — deep / linear / web-to-cluster.
- Lab 2 `bazaar-market` — wide / parallel / three-paths-to-one-crown-jewel.

Everything platform-facing is **reused unchanged** from lab 1: the `lab.yaml`
contract, per-session kind isolation, default-deny NetworkPolicies, the
`checker.ts` invariants+progress pattern, and the kind-based CI smoke test. Only
the app tier and the specific vulns are new.

## Theme

`Bazaar` is a multi-tenant e-commerce platform: buyers browse a storefront,
sellers manage stores via a vendor portal, and a payments service settles
orders. The **crown jewel** is the `payments` service's live API keys, held in a
Kubernetes Secret. "Winning" = exfiltrate those keys and/or reach cluster-admin.

## Topology — three paths in, one jewel out

```
                          BUYERS / SELLERS (internet)
                                     │  NodePort (only exposed surface)
             ┌───────────────────────┼────────────────────────┐
             ▼                        ▼                         ▼
      [ storefront ]           [ vendor API ]            [ assets store ]
   PATH A · AppSec         PATH C · API/authz         PATH B · Cloud/supply-chain
   SSTI in seller          GraphQL introspection      publicly-listable MinIO
   store-theme render      + mass assignment          bucket (misconfig)
             │                        │                         │
             ▼                        ▼                         ▼
   RCE in storefront pod    become platform-admin      leaked CI deploy-token
                            → internal diagnostics       / image-pull secret
             │                  (SSRF / exec)                   │
             │                        │                  push poisoned image
             │                        │                  to internal registry
             └───────────────────────┼─────────────────────────┘
                                      ▼
                    CONVERGENCE — a foothold inside the cluster
                                      │
                 ┌────────────────────┴─────────────────────┐
                 ▼                                           ▼
      payments Secret (Stripe-like keys)          over-permissioned SA /
      = CROWN JEWEL (read-proof)                  registry write → cluster-admin
                                                  (write-proof, as in lab 1)
```

## The three footholds (independent, different domains)

### Path A — AppSec: Server-Side Template Injection
Sellers customize their store page with a "theme" string that the `storefront`
service renders through a template engine **without sandboxing**. A payload like
`{{ 7*7 }}` confirms injection; escalate to RCE in the `storefront` pod. Fresh
vuln class vs. lab 1 (no SQLi/XSS reuse). Domain: web app exploitation.

### Path B — Cloud / supply-chain: exposed object store
The `assets` service is a MinIO bucket that serves product images. It's
**misconfigured for public listing**, and a build artifact left in it leaks a
CI/CD **deploy token** (or an `imagePullSecret`/kubeconfig fragment). Use it to
either talk to the kube API directly or **push a poisoned image** to the internal
registry that a Deployment auto-pulls → code execution as a workload. Domain:
cloud-native / storage / supply-chain.

### Path C — API / authz: GraphQL mass assignment
The `vendor` GraphQL API ships with **introspection enabled** and a profile-update
mutation vulnerable to **mass assignment** — a buyer can set `role: admin` (or
`isPlatformAdmin: true`) on themselves. Platform-admin unlocks an internal
"diagnostics" resolver that proxies requests server-side (SSRF) or runs a health
command (injection), pivoting into the cluster. Domain: API security / broken
authz. Deliberately a *different axis* than lab 1's BOLA (object ownership); this
is privilege-field tampering.

## Convergence + crown jewel

All three land a foothold somewhere in the cluster. From any of them:
- **Read-proof (crown jewel):** the `payments` Secret holds `STRIPE_LIVE_KEY`
  (a fake but realistic-looking token). Reading it and submitting proves data
  exfil.
- **Write-proof (cluster-admin):** same unfakeable mechanism as lab 1 — create a
  gated ConfigMap in `kube-system` that the foothold SA cannot write, forcing a
  real escalation (TokenRequest to a privileged SA, or registry/pod pivot).

## Kubernetes misconfigurations (per path, so escalation differs by route)
- **Path A landing:** `storefront` SA auto-mounts a token with `pods: create`
  (privileged-pod breakout).
- **Path B landing:** the internal registry allows **unauthenticated push**, and a
  Deployment uses `imagePullPolicy: Always` on a `:latest` tag → poisoned image
  runs. The deploy token is also over-scoped.
- **Path C landing:** the diagnostics workload runs with a **cluster-wide
  `secrets: get`** SA (reaches the payments Secret directly).
- **Shared:** no Pod Security admission; `payments` Secret readable by any SA that
  reaches secret-read; registry has no image signing/verification.

## Objective / scoring shape (any-path-wins)
Three independent `foothold-*` objectives (score once for whichever you land),
then two shared convergence objectives (`crown-jewel` read-proof, `cluster-admin`
write-proof). A learner needs **one** foothold path + convergence to complete the
lab; hitting all three paths is bonus/mastery. Wired to the same `checker.ts`
(`invariants` asserts all three paths are exploitable at deploy; `progress`
state-polls the two proofs).

## Proposed layout (mirrors lab 1)
```
bazaar-lab/
├── lab.yaml                 # contract (skeleton included alongside this doc)
├── app/
│   ├── storefront/          # SSTI render (Path A)
│   ├── vendor-api/          # GraphQL introspection + mass assignment (Path C)
│   ├── assets/              # MinIO seed + public-list misconfig (Path B)
│   ├── payments/            # crown-jewel Secret holder
│   └── registry/            # internal registry, unauth push (Path B landing)
├── chart/                   # reuses lab 1's isolation + adds per-path RBAC
└── orchestrator/            # checker.ts + smoke-test.sh (extend lab 1's)
```

## Build order when you're ready
1. `payments` + the crown-jewel Secret + shared RBAC/NetworkPolicy (define the goal first).
2. Path C (GraphQL) — fastest to stand up, exercises the convergence early.
3. Path A (SSTI), then Path B (MinIO + registry) — Path B is the most infra-heavy.
4. Extend `checker.ts`: 3 invariants (one per path) + 2 progress proofs.

## Why this pairs well with lab 1
Together they give your platform two reusable *shapes*: **depth** (chain
discipline, one thing leads to the next) and **breadth** (recon, choosing an
attack surface, not knowing which door is unlocked). Future labs can be tagged
`shape: linear|parallel` so learners can pick the muscle they want to train.
